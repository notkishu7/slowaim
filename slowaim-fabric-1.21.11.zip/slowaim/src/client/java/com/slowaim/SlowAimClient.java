package com.slowaim;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public class SlowAimClient implements ClientModInitializer {
    /** Toggle with /slowaim toggle */
    public static boolean enabled = true;
    /** If true, tick rates above 20 also speed up your aim (off by default). */
    public static boolean scaleFaster = false;

    /** Returns the multiplier to apply to mouse movement: tickRate / 20. */
    public static double getAimScale() {
        if (!enabled) return 1.0;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return 1.0;
        float rate = mc.world.getTickManager().getTickRate();
        double scale = rate / 20.0;
        if (!scaleFaster && scale > 1.0) scale = 1.0;
        return Math.max(scale, 0.0);
    }

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("slowaim")
                .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                    enabled = !enabled;
                    ctx.getSource().sendFeedback(Text.literal("Slow Aim: " + (enabled ? "ON" : "OFF")));
                    return 1;
                }))
                .then(ClientCommandManager.literal("faster").executes(ctx -> {
                    scaleFaster = !scaleFaster;
                    ctx.getSource().sendFeedback(Text.literal("Scale above 20 TPS: " + (scaleFaster ? "ON" : "OFF")));
                    return 1;
                }))
                .then(ClientCommandManager.literal("status").executes(ctx -> {
                    ctx.getSource().sendFeedback(Text.literal(String.format(
                        "Slow Aim %s | current aim scale: %.2fx", enabled ? "ON" : "OFF", getAimScale())));
                    return 1;
                }))));
    }
}
