package com.slowaim.mixin;

import com.slowaim.SlowAimClient;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(Mouse.class)
public class MouseMixin {
    /**
     * Mouse#updateMouse ends by calling player.changeLookDirection(dx, dy).
     * We scale both values by tickRate/20 so aim speed matches the slowed world.
     */
    @ModifyArgs(
        method = "updateMouse",
        at = @At(value = "INVOKE",
                 target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V")
    )
    private void slowaim$scaleAim(Args args) {
        double scale = SlowAimClient.getAimScale();
        if (scale == 1.0) return;
        args.set(0, (double) args.get(0) * scale);
        args.set(1, (double) args.get(1) * scale);
    }
}
