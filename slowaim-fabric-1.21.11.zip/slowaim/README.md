# Slow Aim (Fabric 1.21.11)

Scales your mouse look speed by tickRate / 20.
/tick rate 5 -> aim at 0.25x. Speed the clip up 4x and your aim looks normal.

Commands (client-side):
  /slowaim toggle   turn the mod on/off
  /slowaim faster   also speed up aim when tick rate > 20 (off by default)
  /slowaim status   show current multiplier

Build:
 1. Generate a template at https://fabricmc.net/develop (1.21.11, Yarn, "split sources" ON),
    copy its gradle/ folder, gradlew, gradlew.bat and the version numbers in gradle.properties into this folder.
 2. Run: ./gradlew build   -> jar is in build/libs/
